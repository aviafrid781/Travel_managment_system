/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Traveling_Management_System;

import java.sql.Connection;
import java.sql.DriverManager;


public class mysql_connect {
    
 public static Connection connectDB()    
{
    Connection conn=null;
try
{
Class.forName("com.mysql.jdbc.Driver"); //Register the driver

conn = DriverManager.getConnection("jdbc:mysql://localhost/travel","root", "");
System.out.print("Database is connected !");
//Statement stt = conn.createStatement();
return conn;
}
catch(Exception e)
{
System.out.print("Do not connect to DB - Error:"+e);
return null;
}     
}
}

    
 
